#!/usr/bin/env python3
"""
Carrossel NEON: gera os slides de um carrossel do Instagram (1080x1350 PNG) a partir de um JSON.

Uso:
    python3 render.py carrossel.json [pasta-de-saida]

Formato do JSON:
{
  "marca": {
    "nome": "Minha Marca",
    "arroba": "@minhamarca",
    "fundo": "#0B0C10",        # cor de fundo
    "texto": "#F2F3F7",        # cor do texto principal
    "destaque": "#C6F432",     # cor dos destaques
    "estilo_destaque": "marca-texto"   # "marca-texto" (fundo colorido) ou "cor" (só a letra colorida)
  },
  "slides": [
    {"tipo": "capa", "etiqueta": "GUIA RÁPIDO", "titulo": "Texto com **destaque**", "texto": "Subtítulo opcional"},
    {"tipo": "conteudo", "titulo": "Um ponto por slide", "texto": "Explicação curta, com **palavra-chave** destacada."},
    {"tipo": "cta", "titulo": "Quer o passo a passo?", "texto": "Comenta **SKILL** que eu te mando.", "botao": "COMENTA SKILL"}
  ]
}

Palavras entre **asteriscos** recebem o destaque.
Precisa só de Python 3 e Pillow (pip install pillow). As fontes ficam na pasta fonts/ da skill.
"""
import json
import re
import sys
import zipfile
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont

W, H = 1080, 1350
M = 96  # margem lateral
SKILL_DIR = Path(__file__).resolve().parent.parent
FONTS = SKILL_DIR / "fonts"


def font(name, size):
    path = FONTS / name
    try:
        return ImageFont.truetype(str(path), size)
    except OSError:
        return ImageFont.load_default(size)


BOLD = "SpaceGrotesk-Bold.ttf"
MED = "SpaceGrotesk-Medium.ttf"
MONO = "JetBrainsMono-Medium.ttf"


def hex_rgb(h, fallback):
    try:
        h = h.strip().lstrip("#")
        if len(h) == 3:
            h = "".join(c * 2 for c in h)
        return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))
    except Exception:
        return fallback


def mix(a, b, t):
    return tuple(round(a[i] + (b[i] - a[i]) * t) for i in range(3))


def luminance(c):
    r, g, b = [x / 255 for x in c]
    return 0.2126 * r + 0.7152 * g + 0.0722 * b


def tokens(text):
    """Divide o texto em palavras (palavra, destaque, colada).
    Palavras entre **asteriscos** recebem destaque; pontuação logo depois do destaque fica colada nele."""
    out = []
    parts = re.split(r"\*\*", text or "")
    for i, part in enumerate(parts):
        hl = i % 2 == 1
        glue_first = i > 0 and part[:1] not in ("", " ", "\n") and parts[i - 1][-1:] not in ("", " ", "\n")
        for line_i, line in enumerate(part.split("\n")):
            if line_i > 0:
                out.append(("\n", False, False))
            for j, w in enumerate(line.split()):
                out.append((w, hl, glue_first and line_i == 0 and j == 0))
    return out


def wrap(draw, toks, f, max_w):
    lines, cur, cur_w = [], [], 0
    space = draw.textlength(" ", font=f)
    for w, hl, glue in toks:
        if w == "\n":
            lines.append(cur); cur, cur_w = [], 0
            continue
        ww = draw.textlength(w, font=f)
        add = ww if (not cur or glue) else space + ww
        if cur and not glue and cur_w + add > max_w:
            lines.append(cur); cur, cur_w = [(w, hl, False)], ww
        else:
            cur.append((w, hl, glue)); cur_w += add
    if cur:
        lines.append(cur)
    return lines


def fit(draw, text, fname, max_w, max_h, start, minimum, leading=1.12):
    toks = tokens(text)
    size = start
    while size >= minimum:
        f = font(fname, size)
        lines = wrap(draw, toks, f, max_w)
        if len(lines) * size * leading <= max_h:
            return f, lines, size
        size -= 2
    f = font(fname, minimum)
    return f, wrap(draw, toks, f, max_w), minimum


def block_h(lines, size, leading):
    return len(lines) * size * leading


def draw_lines(draw, lines, f, size, x, y, colors, leading=1.12):
    fg, accent, on_accent, style = colors
    space = draw.textlength(" ", font=f)
    asc, desc = f.getmetrics()
    for line in lines:
        # posições de cada palavra
        pos, cx = [], x
        for i, (w, hl, glue) in enumerate(line):
            if i > 0 and not glue:
                cx += space
            elif i > 0 and glue and line[i - 1][1] and not hl and style == "marca-texto":
                cx += size * 0.16
            ww = draw.textlength(w, font=f)
            pos.append((cx, ww, w, hl))
            cx += ww
        # marca-texto contínuo sobre sequências destacadas
        if style == "marca-texto":
            run = None
            for i, (px, ww, w, hl) in enumerate(pos):
                if hl:
                    run = [px, px + ww] if run is None else [run[0], px + ww]
                if run is not None and (not hl or i == len(pos) - 1):
                    pad = size * 0.14
                    draw.rounded_rectangle([run[0] - pad, y + size * 0.10, run[1] + pad, y + asc + desc * 0.30],
                                           radius=size * 0.12, fill=accent)
                    run = None
        for px, ww, w, hl in pos:
            if hl:
                draw.text((px, y), w, font=f, fill=on_accent if style == "marca-texto" else accent)
            else:
                draw.text((px, y), w, font=f, fill=fg)
        y += size * leading
    return y


def render(spec, out_dir):
    marca = spec.get("marca", {})
    bg = hex_rgb(marca.get("fundo", "#0B0C10"), (11, 12, 16))
    fg = hex_rgb(marca.get("texto", "#F2F3F7"), (242, 243, 247))
    accent = hex_rgb(marca.get("destaque", "#C6F432"), (198, 244, 50))
    on_accent = (11, 12, 16) if luminance(accent) > 0.5 else (255, 255, 255)
    muted = mix(fg, bg, 0.45)
    line_c = mix(fg, bg, 0.82)
    style = marca.get("estilo_destaque", "marca-texto")
    colors = (fg, accent, on_accent, style)
    arroba = marca.get("arroba", "")
    slides = spec.get("slides", [])
    n = len(slides)
    out_dir.mkdir(parents=True, exist_ok=True)
    files = []

    for idx, s in enumerate(slides, 1):
        img = Image.new("RGB", (W, H), bg)
        d = ImageDraw.Draw(img)
        tipo = s.get("tipo", "conteudo")

        # Topo: @ e contador
        fm = font(MONO, 28)
        d.text((M, 84), arroba, font=fm, fill=muted)
        cnt = f"{idx:02d}/{n:02d}"
        d.text((W - M - d.textlength(cnt, font=fm), 84), cnt, font=fm, fill=muted)

        top, bottom = 200, H - 210
        max_w = W - 2 * M

        if tipo == "conteudo":
            num = s.get("numero")
            if num is None:
                num = idx - 1
            fn = font(MONO, 34)
            d.text((M, top), f"{int(num):02d}" if str(num).isdigit() else str(num), font=fn, fill=accent)
            d.line([M + 80, top + 20, W - M, top + 20], fill=line_c, width=2)
            area_top = top + 90
        else:
            area_top = top
        area_h = bottom - area_top
        blocks = []  # (f, lines, size, leading, colors, gap_after)

        if tipo == "capa":
            ft, lines, size = fit(d, s.get("titulo", ""), BOLD, max_w, 620, 128, 64, 1.06)
            blocks.append((ft, lines, size, 1.06, colors, 44))
            if s.get("texto"):
                fb, bl, bs = fit(d, s["texto"], MED, max_w, 260, 46, 30, 1.3)
                blocks.append((fb, bl, bs, 1.3, (muted, accent, on_accent, style), 0))
        elif tipo == "cta":
            ft, lines, size = fit(d, s.get("titulo", ""), BOLD, max_w, 460, 108, 56, 1.08)
            blocks.append((ft, lines, size, 1.08, colors, 36))
            if s.get("texto"):
                fb, bl, bs = fit(d, s["texto"], MED, max_w, 300, 48, 30, 1.3)
                blocks.append((fb, bl, bs, 1.3, (muted, accent, on_accent, style), 48))
        else:
            ft, lines, size = fit(d, s.get("titulo", ""), BOLD, max_w, 440, 92, 50, 1.08)
            blocks.append((ft, lines, size, 1.08, colors, 40))
            if s.get("texto"):
                fb, bl, bs = fit(d, s["texto"], MED, max_w, area_h - block_h(lines, size, 1.08) - 60, 48, 28, 1.34)
                blocks.append((fb, bl, bs, 1.34, (mix(fg, bg, 0.2), accent, on_accent, style), 0))

        tag_h = 90 if (tipo == "capa" and s.get("etiqueta")) else 0
        btn_h = 108 if (tipo == "cta" and s.get("botao")) else 0
        total = tag_h + btn_h + sum(block_h(l, sz, ld) + g for (_, l, sz, ld, _, g) in blocks)
        y = area_top + max(0, (area_h - total) / 2) if tipo != "conteudo" else area_top + max(0, (area_h - total) * 0.35)

        if tag_h:
            fe = font(MONO, 30)
            d.ellipse([M, y + 10, M + 16, y + 26], fill=accent)
            d.text((M + 32, y), s["etiqueta"].upper(), font=fe, fill=muted)
            y += tag_h
        for (f_, l_, sz, ld, col, gap) in blocks:
            y = draw_lines(d, l_, f_, sz, M, y, col, ld) + gap
        if btn_h:
            fbt = font(BOLD, 40)
            tw = d.textlength(s["botao"], font=fbt)
            bw = tw + 112
            d.rounded_rectangle([M, y, M + bw, y + btn_h], radius=btn_h / 2, fill=accent)
            d.text((M + 56, y + btn_h / 2), s["botao"], font=fbt, fill=on_accent, anchor="lm")

        # Rodapé: progresso e "arraste"
        by = H - 120
        seg_gap = 10
        seg_w = (W - 2 * M - seg_gap * (n - 1)) / max(n, 1)
        bar_w = min(seg_w, 60)
        for i in range(n):
            x0 = M + i * (bar_w + seg_gap)
            d.rounded_rectangle([x0, by, x0 + bar_w, by + 8], radius=4, fill=accent if i < idx else line_c)
        if idx < n:
            fa = font(MONO, 28)
            t = "arraste →"
            d.text((W - M - d.textlength(t, font=fa), by - 14), t, font=fa, fill=muted)
        elif marca.get("nome"):
            fa = font(MONO, 28)
            t = marca["nome"]
            d.text((W - M - d.textlength(t, font=fa), by - 14), t, font=fa, fill=muted)

        p = out_dir / f"slide-{idx:02d}.png"
        img.save(p, optimize=True)
        files.append(p)

    z = out_dir / "carrossel.zip"
    with zipfile.ZipFile(z, "w", zipfile.ZIP_DEFLATED) as zf:
        for p in files:
            zf.write(p, p.name)
    return files, z


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print(__doc__)
        sys.exit(1)
    spec = json.loads(Path(sys.argv[1]).read_text(encoding="utf-8"))
    out = Path(sys.argv[2]) if len(sys.argv) > 2 else Path(sys.argv[1]).with_suffix("")
    files, z = render(spec, out)
    print(f"{len(files)} slides gerados em {out}")
    print(f"Arquivo para postar: {z}")
