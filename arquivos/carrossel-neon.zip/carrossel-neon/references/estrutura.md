# Estrutura de um carrossel que segura a pessoa até o fim

## A sequência padrão (8 slides)

1. **Capa (gancho):** a dor ou a promessa, em poucas palavras. Tem que fazer a pessoa arrastar.
2. **Identificação:** mostra que você entende o problema ("Você grava, mas trava na edição").
3. **Promessa:** o que a pessoa vai saber no fim do carrossel.
4. **Ponto 1**
5. **Ponto 2**
6. **Ponto 3**
7. **Virada ou resumo:** o detalhe que muda tudo, ou os pontos em uma frase.
8. **Chamada para ação:** uma ação só, bem clara.

## Ganchos que funcionam (adapte, não copie)

- **Dor direta:** "Pare de perder [tempo/dinheiro] com [problema]."
- **Erro comum:** "O erro que faz [resultado ruim] (e quase todo mundo comete)."
- **Lista:** "[Número] [coisas] que [resultado desejado]."
- **Antes e depois:** "Como eu saí de [situação ruim] para [situação boa]."
- **Segredo:** "O que ninguém te conta sobre [tema]."
- **Comparação:** "[Jeito comum] vs. [jeito melhor]."
- **Pergunta:** uma pergunta que o público já se fez.

## Formatos para variar no calendário

- **Lista de dicas:** 5 a 7 dicas, uma por slide.
- **Passo a passo:** um processo em ordem.
- **Mito vs. verdade:** um mito por slide e a verdade logo abaixo.
- **Erros comuns:** o erro e como corrigir.
- **Antes e depois:** a mesma situação feita do jeito errado e do certo.
- **Reel que virou carrossel:** o roteiro de um vídeo que deu certo, adaptado para leitura.

## Como transformar um Reel em carrossel

1. O gancho do vídeo vira a capa. Encurte para até 12 palavras.
2. Cada parte do roteiro vira um slide. Junte partes curtas e divida as longas.
3. Troque a fala por texto de leitura: frases curtas, sem "né", "tipo", "então".
4. Se o vídeo tinha um "loop aberto" (uma curiosidade deixada para depois), use no slide 3 ou 4 para a pessoa continuar arrastando.
5. A chamada para ação do vídeo vira o último slide.

## Regras de texto

- Título: até 8 palavras.
- Texto do slide: até 30 palavras.
- Uma ideia por slide.
- Destaque de 1 a 4 palavras por slide, nunca a frase inteira.
- Escreva como a pessoa fala, sem termos difíceis.
