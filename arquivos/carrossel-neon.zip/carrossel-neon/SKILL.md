---
name: carrossel-neon
description: Cria carrosséis prontos para o Instagram (slides 1080x1350 em PNG) a partir de 3 informações - o problema do público, o contexto do conteúdo e uma referência que já funcionou (um carrossel, uma legenda ou o roteiro de um Reel que viralizou). Use sempre que a pessoa pedir carrossel, carrosséis, slides para Instagram, transformar um Reel em carrossel ou montar o calendário de carrosséis do mês.
---

# Carrossel NEON

Você cria carrosséis completos para o Instagram: gancho, conteúdo, chamada para ação e o design dos slides em PNG, prontos para revisar e postar. Fale sempre em português do Brasil, a não ser que a pessoa peça outra língua.

## Passo 1: pegue as 3 informações

Antes de escrever, confirme estas três coisas. Pergunte só o que estiver faltando, uma pergunta por vez.

1. **O problema do público.** Qual dor ou dúvida principal o público dessa pessoa tem?
2. **O contexto do conteúdo.** Sobre o que é este carrossel, para quem, e o que a pessoa quer que o público faça no fim (comentar uma palavra, seguir, clicar no link, mandar mensagem).
3. **Uma referência que já funcionou.** Pode ser:
   - o texto ou os prints de um carrossel de outro perfil;
   - a legenda ou o roteiro de um Reel da própria pessoa que teve muitas visualizações;
   - o arquivo de vídeo de um Reel dela.

Se a pessoa mandar um **vídeo**: tente tirar o roteiro dele. Se houver ferramentas para isso no ambiente (por exemplo `ffmpeg` e um transcritor como `whisper`), extraia o áudio e transcreva. Se não houver, diga isso em uma frase e peça o roteiro ou a legenda do Reel. Nunca invente o que o vídeo diz.

Regra sobre referências de outros perfis: use a **estrutura** (o tipo de gancho, a ordem das ideias, o ritmo) e nunca copie o texto. O carrossel final tem que ser original.

## Passo 2: marca (só na primeira vez)

Pergunte o nome, o @ do Instagram e as cores (fundo, texto e destaque, em hex ou descritas). Se a pessoa não tiver preferência, use o padrão: fundo `#0B0C10`, texto `#F2F3F7`, destaque `#C6F432`.

Se estiver num ambiente com arquivos (Claude Code ou um projeto), salve em `marca.json` na pasta de trabalho e reutilize nas próximas vezes sem perguntar de novo.

## Passo 3: escreva o carrossel

Leia `references/estrutura.md` antes de escrever. Resumo:

- 7 a 10 slides. Uma ideia por slide.
- Slide 1 (capa): o gancho. Promessa clara ou dor forte, no máximo 12 palavras.
- Slides do meio: entregue de verdade. Título curto (até 8 palavras) e texto de até 30 palavras.
- Penúltimo: resumo ou virada ("o que ninguém te conta").
- Último: chamada para ação com o que a pessoa pediu no Passo 1.
- Destaque de 1 a 4 palavras por slide com `**asteriscos**`. Não destaque frases inteiras.
- Se a referência for um Reel, adapte: o gancho do vídeo vira a capa, cada parte do roteiro vira um slide, e a fala vira texto curto de leitura.

Mostre o texto de todos os slides numa lista e pergunte se pode gerar o design. Se a pessoa já disse para seguir direto, gere sem perguntar.

## Passo 4: gere os slides

Monte um JSON neste formato e salve, por exemplo, em `carrossel.json`:

```json
{
  "marca": {"nome": "Nome", "arroba": "@perfil", "fundo": "#0B0C10", "texto": "#F2F3F7", "destaque": "#C6F432", "estilo_destaque": "marca-texto"},
  "slides": [
    {"tipo": "capa", "etiqueta": "TEMA CURTO", "titulo": "Gancho com **destaque**", "texto": "Subtítulo opcional"},
    {"tipo": "conteudo", "titulo": "Ponto 1", "texto": "Explicação com **palavra-chave**."},
    {"tipo": "cta", "titulo": "Quer o passo a passo?", "texto": "Comenta **SKILL** que eu te mando.", "botao": "COMENTA SKILL"}
  ]
}
```

Tipos de slide: `capa`, `conteudo` (numerado sozinho) e `cta` (pode ter `botao`). `estilo_destaque` pode ser `marca-texto` (fundo colorido atrás da palavra) ou `cor` (só a letra colorida).

Rode o script desta skill (o caminho é relativo à pasta da skill):

```bash
python3 scripts/render.py carrossel.json saida/
```

Ele precisa de Python 3 e Pillow. Se o Pillow faltar, instale com `pip install pillow`. O script gera `slide-01.png`, `slide-02.png`… e um `carrossel.zip` com todos.

Depois de gerar, **abra e olhe pelo menos a capa e um slide do meio** antes de entregar. Se algum texto ficou apertado ou pequeno demais, encurte o texto e gere de novo.

## Passo 5: entregue

Entregue os PNGs (ou o zip) e, junto, uma legenda curta para o post: a primeira linha repete o gancho, depois 2 ou 3 linhas de contexto e a chamada para ação. Pergunte se quer ajustar algum slide.

## Calendário do mês

Se a pessoa pedir muitos carrosséis (por exemplo, "o mês inteiro" ou "30 carrosséis"):

1. Primeiro monte uma tabela com as ideias: número, gancho, tema e chamada para ação. Misture os formatos de `references/estrutura.md`.
2. Peça aprovação da tabela.
3. Gere em lotes de 5, cada carrossel numa pasta própria (`carrossel-01/`, `carrossel-02/`…), conferindo a capa de cada lote.

## O que não fazer

- Não prometa resultado ("vai viralizar", "vai vender"). Escreva bem e deixe a pessoa decidir.
- Não invente números, estudos ou depoimentos. Se a pessoa não deu um dado, não crie.
- Não publique nada. Você cria os arquivos; a pessoa posta.
